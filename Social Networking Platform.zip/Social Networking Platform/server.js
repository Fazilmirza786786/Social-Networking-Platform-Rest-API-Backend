import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';


//imports the all routes
import authRoutes from "./routes/authRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import postRoutes from "./routes/postRoutes.js";



const server = express();
const port = 5000;




//middleware
server.use(bodyParser.json({limit: '30mb', extended: true}));
server.use(bodyParser.urlencoded({limit: '30mb', extended: true}));

mongoose.connect("mongodb://127.0.0.1:27017/socialnetworking").then((e) =>console.log(`connected to mongodb: ${e.connection.host}`)).catch((e) => console.log(e)); 
server.listen(port, () => console.log(`server listening at ${port}`));
//uses of routes
server.use("/auth", authRoutes);
server.use("/user", userRoutes);
server.use("/post", postRoutes);